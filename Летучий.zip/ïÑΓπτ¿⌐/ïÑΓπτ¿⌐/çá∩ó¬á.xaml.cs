﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace Летучий
{
    /// <summary>
    /// Логика взаимодействия для Заявка.xaml
    /// </summary>

    public partial class Заявка : Window
    {
       
            public string[] names { get; set; }
        public string[] name { get; set; }
    
    
            public Заявка()
        {
            InitializeComponent();
            names = new string[] { "Спортивный", "Детский" };
            DataContext = this;
            name = new string[] { "МБОУ ООШ п.Бор" };
            DataContext = this;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            date1.Text = "";
            b.Text = "";
             c.Text = "";
            q.Text = "";
            w.Text = "";
            g.Text = "";
            r.Text = "";
            t.Text = "";
            y.Text = "";
            u.Text = "";
            i.Text = "";
            o.Text = "";
            p.Text = "";
            s.Text = "";
            d.Text = "";
            f.Text = "";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (date1.Text == "" || q.Text == "" || g.Text == "" || r.Text == "" || t.Text == "" || y.Text == "")
            {

                MessageBox.Show("Введите данные в обязательные поля (*)");

            }

            else
            {
                using (var db = new Летучий_корабльEntities())
                {

                    {
                        child application = new child();
                     //   application.applicationDate = date1.DisplayDate;
                      //  application.byDate = b.DisplayDate;
                     //   application.PurposeOfTheVisit = c.Text;
                        //application.ID_Division = q.;
                     //   application.fullName = g.Text;
                      //  application.agency = o.Text;
                      //  application.comment = p.Text;
                     //   application.phone = u.Text;
                      //  application.E_mail = i.Text;
                       application.Age = s.DisplayDate;
                      //  application.Series = d.Text;
                      //  application.Number = f.Text;
                        application.Surname = r.Text;
                        application.name = t.Text;
                        application.patronymic = y.Text;
                        db.child.Add(application);
                        db.SaveChanges();
                        MessageBox.Show("Заявка отправлена!");
                        //aplication.ID_User = 

                    }

                }

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Личный_кабинет личный_Кабинет = new Личный_кабинет();
            личный_Кабинет.Show();
            Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void c_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void q_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
