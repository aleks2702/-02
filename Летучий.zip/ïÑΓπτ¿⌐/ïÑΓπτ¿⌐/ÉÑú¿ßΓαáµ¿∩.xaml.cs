﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Летучий
{
    /// <summary>
    /// Логика взаимодействия для Регистрация.xaml
    /// </summary>
    public partial class Регистрация : Window
    {
        public Регистрация()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Login.Text == "" || password.Text == "")
            {

                MessageBox.Show("Введите данные в поля: Email и пароль");

            }

            else
            {
                using (var db = new Летучий_корабльEntities())
                {
                    var usern = db.counselors.FirstOrDefault(User => User.Login == Login.Text);
                    if (usern != null)
                    {
                        MessageBox.Show("Login уже используется ");
                    }
                    else
                    {
                        counselors user = new counselors();
                        user.password = password.Text;
                        user.Login = Login.Text;
                        db.counselors.Add(user);
                        db.SaveChanges();
                        MessageBox.Show("Пользователь зарегистрирован");

                    }

                }
            }
        }

        private void avtor_Click(object sender, RoutedEventArgs e)
        {
            Авторизация авторизация = new Авторизация();
            авторизация.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
