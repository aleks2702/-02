﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Летучий
{
    /// <summary>
    /// Логика взаимодействия для Просмотр.xaml
    /// </summary>
    public partial class Просмотр : Window
    {
        public Просмотр()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new Летучий_корабльEntities())
            {
                tgt.ItemsSource = db.child.ToList(); 
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Личный_кабинет личный_Кабинет = new Личный_кабинет();
            личный_Кабинет.Show();
            Close();
        }

        private void tgt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
